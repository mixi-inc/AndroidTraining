package com.example.gmomedia.listviewsample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.example.gmomedia.listviewsample.dummy.DummyContent;
import java.lang.String;
import java.util.List;

/**
 * Created by usr0200475 on 15/04/17.
 */

public class CustomListItemAdapter extends ArrayAdapter<DummyContent.DummyItem> {


    private LayoutInflater mLayoutInflater;

    public CustomListItemAdapter (Context context, List<DummyContent.DummyItem> objects){

        super (context,0,objects);
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

//        View view = null;
//        ViewHolder viewHolder;
        ItemLayout itemLayout;
        // ListViewに表示する分のレイアウトが生成されていない場合レイアウトを作成する
        if (convertView == null) {
            // レイアウトファイルからViewを生成する
             itemLayout = (ItemLayout)mLayoutInflater.inflate(R.layout.listitem_2, parent, false);
//            viewHolder = new ViewHolder();
//            viewHolder.text1 = (TextView) view.findViewById(R.id.id);
//            viewHolder.text2 = (TextView) view.findViewById(R.id.content);
//            view.setTag(viewHolder);
//
        } else {
            // レイアウトが存在する場合は再利用する
//               view = convertView;
//               viewHolder = (ViewHolder) view.getTag();
            itemLayout = (ItemLayout) convertView;

        }

        // リストアイテムに対応するデータを取得する
        DummyContent.DummyItem dummyItem = getItem(position);
        //itemLayout = (ItemLayout) convertView;
        itemLayout.bindView(dummyItem);

//        // 各Viewに表示する情報を設定
//        TextView text1 = (TextView) view.findViewById(R.id.id);
//        text1.setText("Title:" + item.getId());
//        TextView text2 = (TextView) view.findViewById(R.id.content);
//        text2.setText("SubTitle:" + item.getContent());

        return itemLayout;

    }

    static class ViewHolder{
        TextView text1;
        TextView text2;


    }
}

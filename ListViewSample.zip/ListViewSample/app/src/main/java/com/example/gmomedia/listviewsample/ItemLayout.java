package com.example.gmomedia.listviewsample;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.gmomedia.listviewsample.dummy.DummyContent;

import java.util.jar.Attributes;

/**
 * Created by usr0200475 on 15/04/17.
 */
public class ItemLayout extends RelativeLayout {

    TextView id;
    TextView content;

    public ItemLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    protected void onFinishInflate(){
        super.onFinishInflate();

        id = (TextView) findViewById(R.id.id);
        content = (TextView) findViewById(R.id.content);
    }

    public void bindView(DummyContent.DummyItem dummyItem){

        id.setText("id" + dummyItem.getId());
        content.setText("content" + dummyItem.getContent());
    }
}
